const fs = require('fs');
const path = require('path');

function readJsonSync(filePath) {
    // implementation missing
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
}

function appendToFileSync(filePath, text) {
    // implementation missing
    const separator = fs.existsSync(filePath) && fs.readFileSync(filePath, 'utf-8').endsWith('\n') ? '' : '\n';
    fs.appendFileSync(filePath, separator + text);
}

function readJsonAsync(filePath) {
    // implementation missing
    return new Promise((resolve, reject) => {
        fs.readFile(filePath, 'utf-8', (err, data) => {
            if (err) {
                if (err.code === 'ENOENT') {
                    const error = new Error('ENOENT');
                    error.code = 'ENOENT';
                    reject(error);
                } else {
                    reject(new Error(`Error reading JSON file: ${err.message}`));
                }
            } else {
                try {
                    resolve(JSON.parse(data));
                } catch (parseErr) {
                    reject(new Error('Error parsing JSON'));
                }
            }
        });
    });
}

function listDirectoryRecursiveSync(dirPath) {
    // implementation missing
    const listFiles = (currentPath) => {
        const items = fs.readdirSync(currentPath);
        return items.map((item) => {
            const fullPath = path.join(currentPath, item);
            const stat = fs.statSync(fullPath);
            const relativePath = path.relative(dirPath, fullPath).replace(/\\/g, '/');
            if (stat.isDirectory()) {
                return { 
                    type: 'directory', 
                    path: `./resources/${relativePath}`, 
                    children: listFiles(fullPath) 
                };
            } else {
                return { 
                    type: 'file', 
                    path: `./resources/${relativePath}` 
                };
            }
        });
    };
    return listFiles(dirPath);
}


module.exports = {
    readJsonSync,
    appendToFileSync,
    readJsonAsync,
    listDirectoryRecursiveSync,
};
